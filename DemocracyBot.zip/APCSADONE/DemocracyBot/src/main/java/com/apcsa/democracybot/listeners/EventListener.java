package com.apcsa.democracybot.listeners;

import com.apcsa.democracybot.democracyBot;

import net.dv8tion.jda.api.entities.Guild; //DV8FromTheWorld. JDA: Java Discord API. GitHub, https://github.com/DV8FromTheWorld/JDA. Accessed 1 june 2025.
import net.dv8tion.jda.api.entities.UserSnowflake;
import net.dv8tion.jda.api.events.message.MessageReceivedEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;
import org.jetbrains.annotations.NotNull; //JetBrains s.r.o. JetBrains Annotations. JetBrains, https://www.jetbrains.com/help/idea/using-code-inspections.html#annotations. Accessed 1 June 2025.

import java.util.Objects;

public class EventListener extends ListenerAdapter {
    public static Guild guildIdentifier;
    @Override
    public void onMessageReceived(@NotNull MessageReceivedEvent event) {
        String user=event.getAuthor().getName();
        String username=event.getAuthor().getAsTag();
        String userid=event.getAuthor().getId();
        String incMessage=event.getMessage().getContentDisplay();
        String log=username + "sent: "+incMessage;
        String close=event.getMessage().getContentRaw();
        String log2=username + "sent: "+close;
       // event.getGuildChannel().sendMessage(log).queue();
        System.out.println(log2);
        guildIdentifier=event.getGuild();
            for (int i=0;i<com.apcsa.democracybot.democracyBot.test.currentLength();i++)
            {
                if (close.contains(com.apcsa.democracybot.democracyBot.test.wordAt(i)))
                {
                    com.apcsa.democracybot.democracyBot.test.punish(username,userid);
                    event.getGuild().addRoleToMember(UserSnowflake.fromId(userid), Objects.requireNonNull(guildIdentifier.getRoleById(democracyBot.mutedId))).queue(); //add muted role thing
                    System.out.println(user+" has said a banned word: "+ com.apcsa.democracybot.democracyBot.test.wordAt(i));
                    System.out.println("Userid: "+ userid);
                    System.out.println(com.apcsa.democracybot.BanList.currentlyPunished.size());
                }
            }

    }

}