package com.apcsa.democracybot;

public class Users
{
    private final String username;
    private final String userid;
    private int violations=1;
    private int banDuration=1;                                          //base mute duration

    public Users(String username, String userid){
        this.username=username;
        this.userid=userid;
    }

    public void hourPass(){
        banDuration--;
    }

    public boolean doUnmute(){
        System.out.println(username+" has "+banDuration+" hours left.");
        return banDuration <= 0;
    }

    public void repeatOffense() {
        violations++;
        if (violations==2) banDuration=6;                                 //base second mute duration
        else banDuration=12;                                              //base third mute duration
    }
    public int getNumViolations(){
        return violations;
    }
    public String getId(){
        return userid;
    }
    public String getName(){
        return username;
    }
}