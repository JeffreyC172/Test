package com.apcsa.democracybot;
import com.apcsa.democracybot.commands.CommandManager;
import com.apcsa.democracybot.listeners.EventListener;
import javax.security.auth.login.LoginException;

import io.github.cdimascio.dotenv.Dotenv; //cdimascio. java-dotenv. GitHub, https://github.com/cdimascio/java-dotenv. Accessed 1 June 2025.

import net.dv8tion.jda.api.OnlineStatus; //DV8FromTheWorld. JDA: Java Discord API. GitHub, https://github.com/DV8FromTheWorld/JDA. Accessed 29th May 2025.
import net.dv8tion.jda.api.entities.Activity;
import net.dv8tion.jda.api.requests.GatewayIntent;
import net.dv8tion.jda.api.sharding.DefaultShardManagerBuilder;
import net.dv8tion.jda.api.sharding.ShardManager;
import net.dv8tion.jda.api.utils.ChunkingFilter;
import net.dv8tion.jda.api.utils.MemberCachePolicy;
import net.dv8tion.jda.api.utils.cache.CacheFlag;



public class democracyBot {



    public static BanList test = new BanList(); //Banlist
    char commandIdentifier='!';
    private final Dotenv config;
    private final ShardManager shardManager;
    public static String mutedId="1377270174293557398";

    public democracyBot() throws LoginException {
        config=Dotenv.configure().load();
        String token=config.get("TOKEN");
        DefaultShardManagerBuilder builder = DefaultShardManagerBuilder.createDefault(token);
        builder.setStatus(OnlineStatus.ONLINE);
        builder.setActivity(Activity.playing("Testing"));
        builder.enableIntents(GatewayIntent.GUILD_MEMBERS, GatewayIntent.GUILD_MESSAGES);
        builder.setMemberCachePolicy(MemberCachePolicy.ALL);
        builder.setChunkingFilter(ChunkingFilter.ALL);
        builder.enableCache(CacheFlag.ROLE_TAGS);
        shardManager = builder.enableIntents(GatewayIntent.MESSAGE_CONTENT).build();

        shardManager.addEventListener(new EventListener(), new CommandManager());



    }

    public ShardManager getShardManager(){
        return shardManager;
    }

    public Dotenv getConfig(){
        return config;
    }
    public static void main(String[] args){
        try {
            democracyBot bot = new democracyBot();
        } catch (LoginException e) {
            System.out.println("ERROR: BOT TOKEN");
        }
    }

    public BanList getBanList(){
        return test;
    }


}

