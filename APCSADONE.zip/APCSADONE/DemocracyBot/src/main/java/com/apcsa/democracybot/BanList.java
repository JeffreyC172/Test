package com.apcsa.democracybot;

import java.util.ArrayList;

public class BanList {

    private final ArrayList<Word> currentlyBanned = new ArrayList<>();
    private final ArrayList<Word> everBanned = new ArrayList<>();
    public static final ArrayList<Users> currentlyPunished = new ArrayList<>();
    private final ArrayList<Users> trackedUsers = new ArrayList<>();
    private final ArrayList<SuggestedWords> suggestions = new ArrayList<>();

    public BanList() {
    }

    public void punish(String username, String userid){
        boolean isNew = true;
        int location=0;
        for (int i=0;i<trackedUsers.size();i++) {
            if (trackedUsers.get(i).getId().equals(userid)) {
                isNew = false;
                location=i;
                break;
            }
        }
        punishing(isNew, username, userid, location);
    }

    public void punishing(boolean newStatus, String username, String userid,int location){
        if (newStatus) {
            Users newUser = new Users(username, userid);
            currentlyPunished.add(newUser);
            trackedUsers.add(newUser);
        }
        else {
            currentlyPunished.add(trackedUsers.get(location));
            trackedUsers.get(location).repeatOffense();
        }
    }

    public void banSuggest(String suggestion){
        boolean isNew=true;
        System.out.println("Someone is requesting to ban: "+suggestion);
        for (SuggestedWords i : suggestions) {
            if (i.retName().equals(suggestion)) {
                isNew = false;
                i.voted();
                break;
            }
        }
        if (isNew){
            SuggestedWords newSuggestion = new SuggestedWords(suggestion);
            suggestions.add(newSuggestion);
        }
    }
  public String finalizing(){
        if (!(suggestions.isEmpty())) {
            String word = "";
            int timesVoted = 0;
            for (SuggestedWords i : suggestions) {
                if (i.retSugs() > timesVoted) {
                    timesVoted = i.retSugs();
                    word = i.retName();
                }
            }
            banning(word);
            suggestions.clear();
            return word;
        }
        return "";
  }


    public void banning(String incomingWord) {
        boolean isNew = true;
        for (Word i : everBanned) {
            if (i.getWord().equals(incomingWord)) {
                isNew = false;
                break;
            }
        }
        addList(isNew, incomingWord);
    }

    public void addList(boolean isNew, String reBan) {
        if (isNew) {
            Word newWord = new Word(reBan);
            everBanned.add(newWord);
            if (currentlyBanned.size() > 9) {
                currentlyBanned.getFirst().earlyRemove();
                currentlyBanned.removeFirst();
                currentlyBanned.add(newWord);
            } else {
                currentlyBanned.add(newWord);
            }
        } else {
            boolean found = false;
            for (int i = 0; i < currentlyBanned.size(); i++) {
                if (reBan.equals(currentlyBanned.get(i).getWord())) {
                    Word temp = currentlyBanned.get(i);
                    currentlyBanned.get(i).earlyRemove();
                    currentlyBanned.remove(i);
                    currentlyBanned.add(temp);
                    currentlyBanned.getLast().ban();
                    found = true;
                    i = currentlyBanned.size();
                }
            }
            if (!(found)) {
                for (Word i : everBanned) {
                    if (i.getWord().equals(reBan)) {
                        if (currentlyBanned.size() > 9) {
                            currentlyBanned.getFirst().earlyRemove();
                            currentlyBanned.removeFirst();
                        }
                        currentlyBanned.add(i);
                        i.ban();
                    }

                }
            }
        }
    }

    public void passPeriod() {
        for (int i = 0; i < currentlyBanned.size(); i++) {
            currentlyBanned.get(i).dayPass();
            if (currentlyBanned.get(i).doRemove()) {
                currentlyBanned.get(i).earlyRemove();
                currentlyBanned.remove(i);
                i--;
            }
        }
        for (int i=0;i<currentlyPunished.size();i++) {
            currentlyPunished.get(i).hourPass();
        }
    }

    public String current() {
        if (!(currentlyBanned.isEmpty())) {
            StringBuilder ret = new StringBuilder();
            for (int i = 0; i < currentlyBanned.size(); i++) {
                ret.append(currentlyBanned.get(i).wordData());
                if (i < currentlyBanned.size() - 1) ret.append(" ");
            }
            return ret.toString();
        }
        return "No banned words!";
    }

    public int currentLength() {
        return currentlyBanned.size();
    }

    public String wordAt(int i) {
        return currentlyBanned.get(i).getWord();
    }

    public String ever() {
        if (!(everBanned.isEmpty())) {
            StringBuilder ret = new StringBuilder();
            for (int i = 0; i < everBanned.size(); i++) {
                ret.append(everBanned.get(i).wordData());
                if (i < everBanned.size() - 1) ret.append(" ");
            }
            return ret.toString();
        }
        return "No words have ever been banned!";
    }

    public String toString() {
        StringBuilder ret = new StringBuilder("\n" + "Currently Banned");
        ret.append("\n");
        for (int i = 0; i < currentlyBanned.size(); i++) {
            ret.append(currentlyBanned.get(i));
            if (i < currentlyBanned.size() - 1) ret.append(" ");
        }
        ret.append("\n \n Ever Banned \n");
        for (int i = 0; i < everBanned.size(); i++) {
            ret.append(everBanned.get(i));
            if (i < everBanned.size() - 1) ret.append(" ");
        }
        return ret.toString();
    }

   public String unmuteApplicable(Users check){
            if (check.doUnmute()) return check.getId();
            else return "";
   }
}
