package com.apcsa.democracybot;

public class SuggestedWords
{
    private int suggestions=1;
    private final String wordName;

    public SuggestedWords(String suggested){
        wordName=suggested;
    }

    public void voted(){
        suggestions++;
    }
    public String retName(){
        return wordName;
    }
    public int retSugs() {
        return suggestions;
    }

}
