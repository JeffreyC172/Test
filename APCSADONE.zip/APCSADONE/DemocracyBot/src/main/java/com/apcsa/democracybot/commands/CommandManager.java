package com.apcsa.democracybot.commands;

import com.apcsa.democracybot.Users;
import com.apcsa.democracybot.democracyBot;

import net.dv8tion.jda.api.Permission; //DV8FromTheWorld. JDA: Java Discord API. GitHub, https://github.com/DV8FromTheWorld/JDA. Accessed 1 June  2025.
import net.dv8tion.jda.api.entities.Guild;
import net.dv8tion.jda.api.entities.UserSnowflake;
import net.dv8tion.jda.api.events.guild.GuildReadyEvent;
import net.dv8tion.jda.api.events.interaction.command.SlashCommandInteractionEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;
import net.dv8tion.jda.api.interactions.commands.DefaultMemberPermissions;
import net.dv8tion.jda.api.interactions.commands.build.CommandData;
import net.dv8tion.jda.api.interactions.commands.build.Commands;
import static net.dv8tion.jda.api.interactions.commands.OptionType.STRING;
import org.jetbrains.annotations.NotNull; //JetBrains s.r.o. JetBrains Annotations. JetBrains, https://www.jetbrains.com/help/idea/using-code-inspections.html#annotations. Accessed 1 June 2025.

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;


public class CommandManager extends ListenerAdapter {

    @Override
    public void onSlashCommandInteraction(@NotNull SlashCommandInteractionEvent event) {
        String command=event.getName();
        String userTag=event.getUser().getAsTag();
        if (command.equals("checkcurrent")){
            event.reply(com.apcsa.democracybot.democracyBot.test.current()).setEphemeral(true).queue();
        }
        if (command.equals("checkever")){
            event.reply(com.apcsa.democracybot.democracyBot.test.ever()).setEphemeral(true).queue();
        }
        if (command.equals("vote")){
            com.apcsa.democracybot.democracyBot.test.banSuggest(Objects.requireNonNull(event.getOption("word")).getAsString());
            event.reply("Thank you for your vote!").setEphemeral(true).queue();
        }
        if (command.equals("finalizing")){
            String ret=com.apcsa.democracybot.democracyBot.test.finalizing();
            System.out.println("Finalizing Word: " + ret);
            if (ret.isEmpty())
            {
                event.reply("No words have been suggested!").setEphemeral(true).queue();
            }
            else event.reply("Finalizing Vote").setEphemeral(true).queue();
        }
        if (command.equals("unmutecheck")){
            System.out.println("Checking for unmutes!");
            ArrayList<Users> currentlyPunished2= com.apcsa.democracybot.BanList.currentlyPunished;
            Guild guildIdent=com.apcsa.democracybot.listeners.EventListener.guildIdentifier;
            System.out.println(com.apcsa.democracybot.BanList.currentlyPunished.size())
;           System.out.println(currentlyPunished2.size());
            for (Users checking : currentlyPunished2){
                System.out.println(UserSnowflake.fromId(checking.getId()));
                if (checking.doUnmute()) {
                    guildIdent.removeRoleFromMember(UserSnowflake.fromId(checking.getId()), Objects.requireNonNull(guildIdent.getRoleById(democracyBot.mutedId))).queue();
                    System.out.println(UserSnowflake.fromId(checking.getId()) + " was unmuted");
                }
            }
            event.reply("Unmuted applicable users!").setEphemeral(true).queue();
        }
        if (command.equals("skiphour")) {
            com.apcsa.democracybot.democracyBot.test.passPeriod();
            event.reply("Skipping time period!").setEphemeral(true).queue();
        }
    }

    @Override
    public void onGuildReady(@NotNull GuildReadyEvent event) {
        System.out.println("adding commands");
        List<CommandData> commandData = new ArrayList<>();
        commandData.add(Commands.slash("checkcurrent","See all currently banned words."));
        commandData.add(Commands.slash("checkever","See all words ever banned."));
        commandData.add(Commands.slash("vote","Vote on a word to ban!").addOption(STRING, "word", "Word to vote to ban.",true));
        commandData.add(Commands.slash("finalizing","Finalizes ongoing vote.").setDefaultPermissions(DefaultMemberPermissions.enabledFor(Permission.ADMINISTRATOR)));
        commandData.add(Commands.slash("unmutecheck","Unmutes all applicable users.").setDefaultPermissions(DefaultMemberPermissions.enabledFor(Permission.ADMINISTRATOR)));
        commandData.add(Commands.slash("skiphour", "Administrator command to simulate an hour passing.").setDefaultPermissions(DefaultMemberPermissions.enabledFor(Permission.ADMINISTRATOR)));
        event.getGuild().updateCommands().addCommands(commandData).queue();
    }


}
